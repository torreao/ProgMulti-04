//Marcelo Henrique Gomes Torreão 816113657 SI3AN-MCA ProgMulti
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app.module';

platformBrowserDynamic().bootstrapModule(AppModule);

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FecharChamadoPage } from './fechar-chamado';
//Marcelo Henrique Gomes Torreão 816113657 SI3AN-MCA ProgMulti

@NgModule({
  declarations: [
    FecharChamadoPage,
  ],
  imports: [
    IonicPageModule.forChild(FecharChamadoPage),
  ],
})
export class FecharChamadoPageModule {}

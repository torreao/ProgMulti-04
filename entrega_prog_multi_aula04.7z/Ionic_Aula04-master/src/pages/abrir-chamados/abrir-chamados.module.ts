import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AbrirChamadosPage } from './abrir-chamados';
//Marcelo Henrique Gomes Torreão 816113657 SI3AN-MCA ProgMulti

@NgModule({
  declarations: [
    AbrirChamadosPage,
  ],
  imports: [
    IonicPageModule.forChild(AbrirChamadosPage),
  ],
})
export class AbrirChamadosPageModule {}

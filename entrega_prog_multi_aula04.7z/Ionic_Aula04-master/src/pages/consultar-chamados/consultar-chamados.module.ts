import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConsultarChamadosPage } from './consultar-chamados';
//Marcelo Henrique Gomes Torreão 816113657 SI3AN-MCA ProgMulti

@NgModule({
  declarations: [
    ConsultarChamadosPage,
  ],
  imports: [
    IonicPageModule.forChild(ConsultarChamadosPage),
  ],
})
export class ConsultarChamadosPageModule {}
